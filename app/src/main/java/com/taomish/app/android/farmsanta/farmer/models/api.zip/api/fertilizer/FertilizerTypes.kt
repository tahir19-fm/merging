package com.taomish.app.android.farmsanta.farmer.models.api.fertilizer

object FertilizerTypes {

    const val BORON_FERTILIZER = "BORON_FERTILIZER"
    const val NITROGENOUS_FERTILIZER = "NITROGENOUS_FERTILIZER"
    const val NPK_FERTILIZERS = "NPK_FERTILIZERS"
    const val ZINC_FERTILIZER = "ZINC_FERTILIZER"
    const val PHOSPHORUS_FERTILIZER = "PHOSPHORUS_FERTILIZER"
    const val POTASSIC_FERTILIZER = "POTASSIC_FERTILIZER"

}