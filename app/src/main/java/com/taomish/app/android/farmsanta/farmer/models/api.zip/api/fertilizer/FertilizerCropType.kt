package com.taomish.app.android.farmsanta.farmer.models.api.fertilizer

data class FertilizerCropType(
    val type: String,
    val id: Int,
    val label: String
)