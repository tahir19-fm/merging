package com.taomish.app.android.farmsanta.farmer.models.api.fertilizer

object FertilizerLevel {
    const val HIGH = 3
    const val MEDIUM = 2
    const val LOW = 1
}